-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2019 at 10:56 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `semicolon`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--
create database SEMICOLON ;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `idpost` int(11) DEFAULT NULL,
  `name` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `comment` varchar(10000) CHARACTER SET utf16 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `idpost`, `name`, `comment`) VALUES
(1, 54, 'eeeeeeeeeeeeeee', 'ffffffffffffffffff'),
(2, 54, 'eeeeeeeeeeeeeee', 'ffffffffffffffffff'),
(3, 5, 'kk', 'kkk'),
(4, 5, 'm', 'o'),
(5, 5, 'p', 'll'),
(6, 5, 'l', 'nn'),
(7, 5, 'pp', 'nm'),
(8, 5, 'wwwwww', 'wwwwwwwwwww'),
(9, 5, 'll', 'bbbb'),
(10, 5, 'k', 'k'),
(11, 5, 'ppkp', ','),
(12, 5, 'sssssssssssssss', 'ffffffffffffffffffffffffff'),
(13, 5, 'x', 'm'),
(14, 5, 'm', 'm'),
(15, 5, '', 'iiiiiiiiii'),
(16, 5, '', 'dddddddddd'),
(17, 5, '', 'uuuuuuuuu'),
(18, 5, 'dddddd', 'ddddddddddd'),
(19, 5, 'ssssssssss', 'sssssssssssssssss'),
(20, 1, 'ssssssssss', 'sssssssss'),
(21, 1, 'ssssssssssssss', 'ssssssssss'),
(22, 5, 'hhhhhhhhhhhh', 'hhhhhhhhhhhhhh'),
(23, 5, 'qwqq', 'qwqw'),
(24, 2, 'yyyyyyyyy', 'yyyyyyyyyyyyy'),
(25, 2, 'moatazmohamed', 'iiiiiiiiiiiiiiiiiii'),
(26, 2, 'moatazmohamed', 'vvvvvvvvvvvv'),
(27, 2, 'moatazmohamed', 'ooooooooooooooo'),
(28, 2, 'moatazmohamed', 'hhh'),
(29, 2, 'moatazmohamed', 'gg'),
(30, 2, 'moatazmohamed', 'ddddddddddddd'),
(31, 2, 'moatazmohamed', 'sss'),
(32, 1, 'moatazmohamed', 'ggg'),
(33, 1, 'moatazmohamed', 'ii'),
(34, 1, 'moatazmohamed', 'vvv'),
(35, 1, 'moatazmohamed', 'll'),
(36, 1, 'moatazmohamed', 'kk'),
(37, 1, 'moatazmohamed', 'hhhhhhhhh'),
(38, 54, 'moatazmohamed', 'vv'),
(39, 54, 'moatazmohamed', 'dddddddd'),
(40, 53, 'moatazmohamed', 'mmm'),
(41, 54, 'moatazmohamed', 'bb'),
(42, 54, 'moatazmohamed', 'bb'),
(43, 51, 'moatazmohamed', 'qqq'),
(44, 54, 'moatazmohamed', 'ee'),
(45, 54, 'moatazmohamed', 'pp'),
(46, 53, 'moatazmohamed', 'pp'),
(47, 52, 'moatazmohamed', 'zz'),
(48, 46, 'moatazmohamed', 'mm'),
(49, 58, 'moatazmohamed', 'dddddddddddd'),
(50, 59, 'moatazmohamed', 'zz'),
(51, 59, 'moatazmohamed', 'aaa'),
(52, 47, 'moatazmohamed', '2'),
(53, 61, 'moataz.mohamed', 'zz'),
(54, 1, 'moataz1mohamed', 'wwwwwwwwwwwww'),
(55, 64, 'moataz1mohamed', 'zzzzzzzzzzzzzzzzz'),
(56, 66, 'moataz1mohamed', 'sssssssssss');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `idpost` int(11) DEFAULT NULL,
  `iduser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `idpost`, `iduser`) VALUES
(29, 1, 1),
(30, 54, 1),
(31, 53, 1),
(32, 54, 1),
(34, 54, 1),
(35, 54, 1),
(36, 54, 1),
(37, 52, 2),
(38, 54, 1),
(39, 54, 1),
(40, 54, 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `idpost` int(11) NOT NULL,
  `idfriend` int(11) DEFAULT NULL,
  `username` varchar(1000) CHARACTER SET utf16 NOT NULL,
  `date_time` datetime(6) DEFAULT NULL,
  `like_post` int(11) DEFAULT NULL,
  `source` varchar(10000) CHARACTER SET utf16 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`idpost`, `idfriend`, `username`, `date_time`, `like_post`, `source`) VALUES
(1, NULL, 'moataz1mohamed', '2019-03-22 06:39:44.000000', NULL, 'hello world\r\n'),
(2, NULL, 'moataz1mohamed', '2019-03-22 06:40:34.000000', NULL, 'mama i coming home'),
(4, NULL, 'moatazmohamed', '2019-04-12 06:40:08.000000', NULL, 'say hello to me'),
(5, NULL, 'moatazmohamed', '2019-04-12 05:40:38.000000', NULL, 'say it'),
(14, NULL, 'moatazmohamed', '2019-04-12 08:53:48.000000', NULL, 'hello bye'),
(31, NULL, 'moatazmohamed', '2019-04-13 01:08:08.000000', NULL, 'hello'),
(44, NULL, 'moatazmohamed', '2019-04-13 01:17:14.000000', NULL, 'fuck u'),
(45, NULL, 'moatazmohamed', '2019-04-14 03:43:39.000000', NULL, 'go back'),
(46, NULL, 'moatazmohamed', '2019-04-14 03:44:24.000000', NULL, 'hh'),
(47, NULL, 'moatazmohamed', '2019-04-14 02:09:06.000000', NULL, 'fuck'),
(48, NULL, 'moatazmohamed', '2019-04-14 02:09:41.000000', NULL, 'fuck'),
(49, NULL, 'moatazmohamed', '2019-04-14 02:10:08.000000', NULL, 'fuck again'),
(50, NULL, 'moatazmohamed', '2019-04-14 02:10:20.000000', NULL, 'fuck again'),
(51, NULL, 'moatazmohamed', '2019-04-14 02:10:33.000000', NULL, 'fuck 2'),
(52, NULL, 'moatazmohamed', '2019-04-20 07:58:35.000000', NULL, 'see me'),
(53, NULL, 'moataz1mohamed', '2019-05-01 04:00:33.000000', NULL, 'oooooooooooooo'),
(54, NULL, 'moataz1mohamed', '2019-05-01 04:00:43.000000', NULL, 'jj'),
(57, NULL, 'moatazmohamed', '2019-05-19 08:52:06.000000', NULL, 'jj'),
(58, NULL, 'moatazmohamed', '2019-05-19 08:53:08.000000', NULL, 'see me'),
(59, NULL, 'moatazmohamed', '2019-05-19 08:54:59.000000', NULL, 'see me'),
(60, NULL, 'moatazmohamed', '2019-05-19 09:11:20.000000', NULL, 'ttttttttttt'),
(61, NULL, 'moatazmohamed', '2019-05-19 05:36:57.000000', NULL, 'ttttttttttt'),
(62, NULL, 'moatazmohamed', '2019-06-02 06:38:28.000000', NULL, 'see me'),
(63, NULL, 'moataz1mohamed', '2019-06-05 07:19:02.000000', NULL, 'zzzzzzzzzzzzzzzz'),
(64, NULL, 'moataz1mohamed', '2019-06-05 07:19:10.000000', NULL, 'mmmmmmmmmmmmmm'),
(65, NULL, 'moataz1mohamed', '2019-06-05 07:22:05.000000', NULL, 'eeeeeeeeeeeeeeee'),
(66, NULL, 'moataz1mohamed', '2019-06-05 07:28:31.000000', NULL, 'zzzzzzzzzzzzzz');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `iduser` int(11) NOT NULL,
  `firstname` varchar(100) CHARACTER SET utf16 NOT NULL,
  `lastname` varchar(100) CHARACTER SET utf16 NOT NULL,
  `username` varchar(100) CHARACTER SET utf16 NOT NULL,
  `img` varchar(100) CHARACTER SET utf16 NOT NULL,
  `aboutme` varchar(100) CHARACTER SET utf16 NOT NULL,
  `location` varchar(100) CHARACTER SET utf16 NOT NULL,
  `email` varchar(100) CHARACTER SET utf16 NOT NULL,
  `password` varchar(100) CHARACTER SET utf16 NOT NULL,
  `birthday` date DEFAULT NULL,
  `facebook` varchar(1000) CHARACTER SET utf16 DEFAULT NULL,
  `twitter` varchar(1000) CHARACTER SET utf16 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iduser`, `firstname`, `lastname`, `username`, `img`, `aboutme`, `location`, `email`, `password`, `birthday`, `facebook`, `twitter`) VALUES
(1, 'moataz', 'mohamed', 'moataz1mohamed', '01 - Copy.jpg', 'student', 'egypthkkk', 'mohamed.moataz194@gmail.com', '01289', '1999-03-18', 'hhhhhhhhhhhhh', 'twitter.com'),
(2, 'moataz', 'mohamed', 'moatazmohamed', 'FB_IMG_1490093578988.jpg', 'still student 0', 'alex', 'moatazmohame@gmail.com', '01289', '1999-01-01', NULL, NULL),
(10, 'a', 'a', 'a', 'avatar6.png', '', '', 'a@gmail.com', 'a', NULL, NULL, NULL),
(11, 'x', 'x', 'x', 'avatar6.png', '', '', 'x@gmail.com', 'x', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idpost` (`idpost`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idpost` (`idpost`),
  ADD KEY `iduser` (`iduser`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`idpost`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`iduser`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email_2` (`email`),
  ADD UNIQUE KEY `username_2` (`username`),
  ADD UNIQUE KEY `email_3` (`email`),
  ADD UNIQUE KEY `username_3` (`username`),
  ADD UNIQUE KEY `email_4` (`email`),
  ADD UNIQUE KEY `username_4` (`username`),
  ADD UNIQUE KEY `email_5` (`email`),
  ADD UNIQUE KEY `username_5` (`username`),
  ADD UNIQUE KEY `email_6` (`email`),
  ADD UNIQUE KEY `username_6` (`username`),
  ADD UNIQUE KEY `email_7` (`email`),
  ADD UNIQUE KEY `username_7` (`username`),
  ADD UNIQUE KEY `email_8` (`email`),
  ADD UNIQUE KEY `username_8` (`username`),
  ADD UNIQUE KEY `email_9` (`email`),
  ADD UNIQUE KEY `username_9` (`username`),
  ADD UNIQUE KEY `email_10` (`email`),
  ADD UNIQUE KEY `email_11` (`email`),
  ADD UNIQUE KEY `username_10` (`username`),
  ADD UNIQUE KEY `username_11` (`username`),
  ADD UNIQUE KEY `email_12` (`email`),
  ADD UNIQUE KEY `username_12` (`username`),
  ADD UNIQUE KEY `email_13` (`email`),
  ADD UNIQUE KEY `username_13` (`username`),
  ADD UNIQUE KEY `email_14` (`email`),
  ADD UNIQUE KEY `username_14` (`username`),
  ADD UNIQUE KEY `email_15` (`email`),
  ADD UNIQUE KEY `username_15` (`username`),
  ADD UNIQUE KEY `email_16` (`email`),
  ADD UNIQUE KEY `username_16` (`username`),
  ADD UNIQUE KEY `email_17` (`email`),
  ADD UNIQUE KEY `username_17` (`username`),
  ADD UNIQUE KEY `email_18` (`email`),
  ADD UNIQUE KEY `username_18` (`username`),
  ADD UNIQUE KEY `email_19` (`email`),
  ADD UNIQUE KEY `username_19` (`username`),
  ADD UNIQUE KEY `email_20` (`email`),
  ADD UNIQUE KEY `username_20` (`username`),
  ADD UNIQUE KEY `email_21` (`email`),
  ADD UNIQUE KEY `username_21` (`username`),
  ADD UNIQUE KEY `email_22` (`email`),
  ADD UNIQUE KEY `username_22` (`username`),
  ADD UNIQUE KEY `email_23` (`email`),
  ADD UNIQUE KEY `username_23` (`username`),
  ADD UNIQUE KEY `email_24` (`email`),
  ADD UNIQUE KEY `username_24` (`username`),
  ADD UNIQUE KEY `email_25` (`email`),
  ADD UNIQUE KEY `username_25` (`username`),
  ADD UNIQUE KEY `email_26` (`email`),
  ADD UNIQUE KEY `username_26` (`username`),
  ADD UNIQUE KEY `email_27` (`email`),
  ADD UNIQUE KEY `username_27` (`username`),
  ADD UNIQUE KEY `email_28` (`email`),
  ADD UNIQUE KEY `username_28` (`username`),
  ADD UNIQUE KEY `email_29` (`email`),
  ADD UNIQUE KEY `username_29` (`username`),
  ADD UNIQUE KEY `email_30` (`email`),
  ADD UNIQUE KEY `username_30` (`username`),
  ADD UNIQUE KEY `email_31` (`email`),
  ADD UNIQUE KEY `username_31` (`username`),
  ADD UNIQUE KEY `email_32` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `idpost` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`idpost`) REFERENCES `post` (`idpost`),
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`idpost`) REFERENCES `post` (`idpost`);

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`idpost`) REFERENCES `post` (`idpost`),
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`iduser`) REFERENCES `user` (`iduser`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
