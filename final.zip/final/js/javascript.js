function publication(){
    document.getElementById('form-group').style.display = 'block';
    document.getElementById('custom-file').style.display = 'none';
}
function images123(){
    document.getElementById('custom-file').style.display='block';
    document.getElementById('form-group').style.display='none'; 
}
function fa_globe(){
    document.getElementById('faaaa').className='fa fa-globe';
}
function fa_users(){
    document.getElementById('faaaa').className='fa fa-users';   
}
function fa_user(){
    document.getElementById('faaaa').className='fa fa-user';
}
/*
function share133(){
    if ($('textarea').val()){
        
       // document.write("kjfn");
         var elems ='<center>'+
'    <div class="post" id="post">'+
            '<div class="posthead">'+
'             <img id="pro1" src="http://bootdey.com/img/Content/avatar/avatar6.png">'+
 '           <h7 id="name1" style="font-size: 20px;"><a href="">His Name</a></h7>'+
  '          </div>'+
'            <hr>'+
'            <div class="text-muted h7 mb-2"> <i class="fa fa-clock-o"></i>10 min ago</div><br>'+
'<div class="text2">'+$('textarea').val()+'</div><br>'+
'        <hr>'+
'            <div class="card-footer">'+
'                <a href="#" class="card-link"><i class="fa fa-gittip"></i> Like</a>'+
'                <a href="#" class="card-link1"><i class="fa fa-comment"></i> Comment</a>'+
'                <a href="#" class="card-link2"><i class="fa fa-mail-forward"></i> Share</a>'+
'            </div>'+
'        </div>'+
'</center>';
        $('#firstt').prepend(elems);
        
    }
}
*/