
function viewPassword()
{
  var passwordInput = document.getElementById('user123');
  var passStatus = document.getElementById('open');
 
  if (passwordInput.type == 'password'){
    passwordInput.type='text';
    passStatus.className='fa fa-eye-slash';
    
  }
  else{
    passwordInput.type='password';
    passStatus.className='fa fa-eye';
  }
}
function viewPassword1()
{
  var passwordInput1 = document.getElementById('passwordd');
  var passStatus1 = document.getElementById('openeyes');
 
  if (passwordInput1.type == 'password'){
    passwordInput1.type='text';
    passStatus1.className='fa fa-eye-slash';
    
  }
  else{
    passwordInput1.type='password';
    passStatus1.className='fa fa-eye';
  }
}