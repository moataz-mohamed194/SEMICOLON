function edit(){
	
	 document.getElementById('col-sm-1555').style.display='block';
	document.getElementById('col-sm-15555').style.display='block';
	document.getElementById('col-sm-155').style.display='block';
	document.getElementById('col-sm-15').style.display='block';
	
	document.getElementById('col-sm-9').style.display='none';
	document.getElementById('col-sm-99').style.display='none';
}
function EndEdit(){
	
	 document.getElementById('col-sm-1555').style.display='none';
	document.getElementById('col-sm-15555').style.display='none';
	document.getElementById('col-sm-155').style.display='none';
	document.getElementById('col-sm-15').style.display='none';
	
	document.getElementById('col-sm-9').style.display='block';
	document.getElementById('col-sm-99').style.display='block';
}
