<?php

	$cookie_name = 'semicolon';
$cookie_value = 'eeooo';
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), '/');
 header("Location:../finish.php");
?>