<?php
	include "create/database.php";
	$date=date("y-m-d h:i:s",time()+0*60*60);
	$us=$_COOKIE['semicolon'];
    $source1=$_POST['thatpost'];
    $stmt = $connect->query("INSERT INTO `post` (`username`,`date_time`, `source`) VALUES ('$us','$date', '$source1');");
    header("Location:home.php");
    exit();
?>