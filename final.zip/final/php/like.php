<?php
$username = 'root';
  	
$password = '';
  	
$first = 'mysql:host=localhost;dbname=semicolon';
  	
$connect = new PDO($first, $username, $password);
  		$idpost=$row["idpost"];
	$getUse = $connect->prepare("SELECT * FROM user WHERE username='".$_COOKIE['semicolon']."'");
      $getUse->execute();
      $use = $getUse->fetchAll();
      foreach ($use as $us) 
      {
	$iduser=$us["iduser"];
echo $iduser . $idpost;
}
?>