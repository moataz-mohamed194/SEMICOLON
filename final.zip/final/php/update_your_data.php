<?php
	  $img=$_POST['Update_your_image'];
      $Location=$_POST['Location'];
      $Birthday=$_POST['Birthday'];
      $facebook=$_POST['facebook'];
      $twitter=$_POST['twitter'];
      $Updateyourdata=$_POST['aboutme'];
      $getUse = $connect->prepare("SELECT * FROM user WHERE username='".$_COOKIE['semicolon']."'");
      $getUse->execute();
      $use = $getUse->fetchAll();
      foreach ($use as $us) 
      {
          $file_name = $_FILES['Update_your_image']['name']; 
          $file_size =$_FILES['Update_your_image']['size']; 
          $file_tmp =$_FILES['Update_your_image']['tmp_name']; 
          $file_type=$_FILES['Update_your_image']['type']; 
          $tmp = dirname(__FILE__) . "\..\photo\\" . $file_name;
        if(!empty($file_tmp))
        {
        	$sql = "UPDATE user SET img =?  WHERE iduser =?";
        	$connect->prepare($sql)->execute([ $file_name ,$us['iduser']]);
        	$ok  = move_uploaded_file($file_tmp,$tmp );
        }
        if(!empty($_POST['Birthday']))
        {
        	$sql = "UPDATE user SET birthday  =? WHERE iduser =?";
        	$connect->prepare($sql)->execute([$Birthday , $us['iduser']]);
        }
        if(!empty($_POST['Location']))
        {
            $sql = "UPDATE user SET location  =? WHERE iduser =?";
	        $connect->prepare($sql)->execute([$Location , $us['iduser']]);
        }
        if(!empty($_POST['facebook']))
        {
        	$sql = "UPDATE user SET facebook  =? WHERE iduser =?";
        	$connect->prepare($sql)->execute([$facebook , $us['iduser']]);
        }
        if(!empty($_POST['twitter']))
        {
        	$sql = "UPDATE user SET twitter  =? WHERE iduser =?";
        	$connect->prepare($sql)->execute([$twitter , $us['iduser']]);
        }
        if(!empty($_POST['aboutme']))
        {
        	$sql = "UPDATE user SET aboutme  =? WHERE iduser =?";
        	$connect->prepare($sql)->execute([$Updateyourdata , $us['iduser']]);
        }
        header("Location:../pages/profile.php");
        exit;
      }
      /*
		 header("Location:/task/final/pages/profile.php");
        exit;
      */
?>