<?php
include "create/database.php";
ob_start();

//	header_remove("home.php");

  $queryy ="SELECT * FROM comment WHERE idpost='$idpost'; ";
    $dataa=$connect->query($queryy);
   
     foreach ($dataa as $roww) 
    {
        echo '<p>'. $roww['comment'].' </p><hr>';
      }
echo ' </div>
</div>';
    if(isset($_POST['sentcomment'. $idpost.'' ]))
    {  
	    $idpost=$row["idpost"];
        $sourc=$_POST['addcomment'. $idpost .''];
        $stmt = $connect->query("INSERT INTO `comment` (`idpost`,`comment`) VALUES ('$idpost','$sourc');");   
         header("Location:../pages/home.php");
         exit();
       // Error it doesn't work , when i refresh page it's sent data again
         // header("Refresh:0; url=home.php");
    }
    echo '<script type="text/javascript" src="../js/javascript.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
        <script>
// Get the modal
var modal = document.getElementById(\'id01'. $row["idpost"] .'\');
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>';
?>