<?php
include "create/database.php";

	    $username1=$_POST['username999'];
    $password=$_POST['password999'];
    $getUsers = $connect->prepare("SELECT * FROM user WHERE username='".$username1."'");
    $getUsers->execute();
    $users = $getUsers->fetchAll();
    foreach ($users as $user) 
    {
      if($password==$user['password'])
      {
        setcookie("semicolon",$username1 );
        header("Location:../final/pages/home.php");
        exit;
      }
      if ($password!=$user['password']) 
      {
        //  header("Location:try - Copy.php");
        //echo "not the same";
        echo "<script type='text/javascript'>";
        echo "alert(\"wrong passsword\")";
        echo "</script>";
        exit;
      }
    }
?>