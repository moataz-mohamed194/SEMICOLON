<?php
	 $first = 'mysql:host=localhost';
  	$username = 'root';
  	$password = '';
  	$sqlcreate = "CREATE DATABASE IF NOT EXISTS `semicolon`";
  	$connect = new PDO($first, $username, $password);
  	$connect->exec($sqlcreate);
  	$first = 'mysql:host=localhost;dbname=semicolon';
  	$connect = new PDO($first, $username, $password);
  	$username = 'root';
  	$password = '';
  	$dsn = 'mysql:host=localhost;dbname=semicolon';
  	$conn=new mysqli( "localhost","root","","semicolon");
?>