<?php
include "database.php";
	$tablecreate = "CREATE TABLE IF NOT EXISTS `user`( iduser INT( 11 ) AUTO_INCREMENT PRIMARY KEY, firstname VARCHAR( 1000000 ) NULL, lastname VARCHAR( 1000000 ) NULL, username VARCHAR( 1000000 ) NULL, img VARCHAR( 1000000 ) NULL, aboutme VARCHAR( 1000000 ) NULL, location VARCHAR( 1000000 ) NULL, email VARCHAR( 50 ) NULL, password VARCHAR( 1000000 ) NULL );";
  $tablecreate1 = "ALTER TABLE `user` ADD `birthday` DATE NOT NULL AFTER `password`;";
  $tablecreate11 = "ALTER TABLE `user` CHANGE `firstname` `firstname` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `lastname` `lastname` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `img` `img` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `aboutme` `aboutme` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `location` `location` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `email` `email` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `password` `password` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL;";
  $connect = new PDO($first, $username, $password);
  $connect->exec($tablecreate);
  $connect->exec($tablecreate1);
  $connect->exec($tablecreate11);
  $ft="ALTER TABLE `user` ADD `facebook` VARCHAR(1000) CHARACTER SET utf16 COLLATE utf16_general_ci NULL AFTER `birthday`, ADD `twitter` VARCHAR(1000) CHARACTER SET utf16 COLLATE utf16_general_ci NULL AFTER `facebook`;
";
$connect->exec($ft);
  $utf16 = "ALTER TABLE `user` CHANGE `firstname` `firstname` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `lastname` `lastname` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,CHANGE `username` `username` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `img` `img` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `aboutme` `aboutme` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `location` `location` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `email` `email` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL, CHANGE `password` `password` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL;";
  $connect->exec($utf16);
  $sqluniqe = "ALTER TABLE `user` ADD UNIQUE( `email`);";
  $connect->exec($sqluniqe);

  $us = "ALTER TABLE `user` ";
  $null="ALTER TABLE `user` CHANGE `img` `img` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NULL, CHANGE `aboutme` `aboutme` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NULL, CHANGE `location` `location` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NULL, CHANGE `birthday` `birthday` DATE NULL;";
  $connect->exec($null);
  $connect->exec($us);
  $username_uniqe = "ALTER TABLE `user` ADD UNIQUE( `username`);";
  $im="ALTER TABLE `user` CHANGE `img` `img` VARCHAR(100) CHARACTER SET utf16 COLLATE utf16_general_ci NULL DEFAULT 'http://bootdey.com/img/Content/avatar/avatar6.png';";
  $connect->exec($im);
  $connect->exec($username_uniqe);
?>