<?php
include "database.php";
$first = 'mysql:host=localhost';
    $username = 'root';
    $password = '';
    $sqlcreate = "CREATE DATABASE IF NOT EXISTS `semicolon`";
    $connect = new PDO($first, $username, $password);
    $connect->exec($sqlcreate);
    $first = 'mysql:host=localhost;dbname=semicolon';
    //to creat the database
    $tablecreate = "CREATE TABLE IF NOT EXISTS `post`( idpost INT( 11 ) AUTO_INCREMENT PRIMARY KEY, idfriend INT( 11 ), username VARCHAR( 1000 ) NOT NULL, date_time DATETIME( 6 ) , like_post INT( 11 ) , source VARCHAR( 1000000 ) NOT NULL );";
    $tablecreate11 = "ALTER TABLE `post` CHANGE `source` `source` MEDIUMTEXT CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL;";
    $connect = new PDO($first, $username, $password);
    $connect->exec($tablecreate);
    $connect->exec($tablecreate11);

    $tablecreate2 = "CREATE TABLE IF NOT EXISTS `likes`( idpost INT( 11 ) , iduser INT( 11 ) );";
    $connect = new PDO($first, $username, $password);
    $connect->exec($tablecreate2);
    $date=date("y-m-d h:i:s",time()+1*60*60);
    $edit="ALTER TABLE `post` CHANGE `source` `source` VARCHAR(10000) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,CHANGE `username` `username` VARCHAR(1000) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL;";
    $connect->exec($edit);
    //to creat the table 
    $tablecreate3 = "CREATE TABLE IF NOT EXISTS `comment`( idpost INT( 11 ) , comment VARCHAR( 1000000 ) );";
    $connect = new PDO($first, $username, $password);
    $connect->exec($tablecreate3);
    $edit2 = "ALTER TABLE `comment` CHANGE `comment` `comment` VARCHAR(10000) CHARACTER SET utf16 COLLATE utf16_general_ci NULL DEFAULT NULL;";
  
    $connect->exec($edit2);

?>