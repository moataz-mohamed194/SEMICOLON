<?php
	header_remove($header);
	header("Location:home2.php");
	exit();
?>