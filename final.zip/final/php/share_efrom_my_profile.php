<?php
    include "/create/database.php";
	$date=date("y-m-d h:i:s",time()+0*60*60);
	$us=$_COOKIE['semicolon'];
    $source1=$_POST['thatpost'];
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line
	$sql = "INSERT INTO post (`username`,`date_time`, `source`)VALUES ('$us','$date', '$source1');";
	if ($connect->query($sql))
	{
		header("Location:../pages/profile.php");
    	exit();
	}
?>