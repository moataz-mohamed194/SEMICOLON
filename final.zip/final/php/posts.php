<?php include "create/database.php";
  ob_start();

 include "create/database.php";
    $query ="SELECT * FROM post ORDER BY idpost desc ";
    $data=$connect->query($query);
    foreach ($data as $row) 
    {
      $g = $connect->prepare("SELECT * FROM user WHERE username='".$row['username']."'");
      $g->execute();
      $u = $g->fetchAll();
  $idpost=$row["idpost"];
  
 /* if(isset($_POST['sentcomment'. $idpost.'' ]))
    { 
    
        $sourc=$_POST['addcomment'. $idpost .''];
        $stmt = $connect->query("INSERT INTO `comment` (`idpost`,`comment`) VALUES ('$idpost','$sourc');");
       // Error it doesn't work , when i refresh page it's sent data again
         //header("Location:../pages/home.php");
         // exit();
         // header("Refresh:0; url=home.php");
    }*/

      foreach ($u as $us1) 
      {
      //http://bootdey.com/img/Content/avatar/avatar6.png
      //../photo/'.$row['img'].'
        global $idposttt;
        $idposttt=$row["idpost"];
         $idpost=$row["idpost"];
       echo' <center>'.
'         <div class="post" id="post">
            <div class="posthead">
             <img id="pro1" src="../photo/'.$us1['img'].'">
            <h7 id="name1" style="font-size: 20px;"><a href="../pages/profile.php">'. $row["username"] .'</a></h7>
            </div>
            <hr>
            <div class="text-muted h7 mb-2"> <i class="fa fa-clock-o"></i>'. $row["date_time"] .'</div><br>
<div class="text2">'. $row["source"] .'</div><br>
        <hr>
            <div class="card-footer">
                <a href="home.php?reset'. $row["idpost"] .'=true" class="card-link"><i class="fa fa-gittip"></i> Like</a>
                <a href="#" onclick="document.getElementById(\'id01'. $row["idpost"] .'\').style.display=\'block\'" class="card-link1"><i class="fa fa-comment"></i> Comment</a>
          </div>
        </div>
</center>';
echo '<div id="id01'. $row["idpost"] .'" class="modal">
  <span onclick="document.getElementById(\'id01'. $row["idpost"] .'\').style.display=\'none\'" class="close" title="Close Modal">&times;</span>
  <div class="modal-content" >
     <form method="post" id="comment_form" style="margin:20px;  ">
        <div class="form-group" id="form-group">    
            <textarea class="comment-control" name="addcomment'. $row["idpost"] .'" id="message" cols="120" rows="5" placeholder="add your comment ............"></textarea>
        </div>
        <input id="add" type="submit"   class="addcomment" value="sent" name="sentcomment'. $row["idpost"] .'">
   </form>';
 }
       include 'comment.php';
        } ?>
</body>
</html>
