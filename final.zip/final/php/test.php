<?php include "/create/database.php";


 $getUse = $connect->prepare("SELECT * FROM user WHERE username='".$_row['username']."'");
      $getUse->execute();
      $use = $getUse->fetchAll();
      foreach ($use as $us) 
      {
echo $us['img'];
      }













?>
