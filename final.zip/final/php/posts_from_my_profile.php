<?php include "/create/database.php";?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="../js/javascript.js"></script>
    <meta name="description" content="">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="shortcut icon"  href="../photo/SEMICOLON.jpg">
    <title>SEMICOLON</title>
    <style type="text/css">
    </style>
</head>
<body style=""> 

 	<?php  
 	 $day=date("Y-m-d");
   $query ="SELECT * FROM post ORDER BY idpost desc ";
    $data=$connect->query($query);

        		foreach ($data as $row) 
        		{
    				if ($row["username"]==$_COOKIE['semicolon']) 
    				{
        	  $g = $connect->prepare("SELECT * FROM user WHERE username='".$row['username']."'");
      $g->execute();
      $u = $g->fetchAll();
      foreach ($u as $us1) 
      {
        echo'<script>
 $(document).ready(function(){
  $(".card-link'. $row["idpost"] .'").click(function(){';
       
  echo' var source ="'.$row["source"].'";
   var iduser =0;
    $.ajax({
      url: \'like_comments.php\',
      type: \'post\',
      data: 
      {
        source: source,
        iduser: iduser
      },
      success: function(response)
      {
        alert("that post is shared");';
       
echo'        }
      });
  });
});</script>
';
        $idpost=$row["idpost"];
       echo' <center>'.
'         <div class="post" id="post" style="margin-left: 30px;">
            <div class="posthead">
             <img id="pro1" src="../photo/'.$us1['img'].'">
            <h7 id="name1" style="font-size: 20px;font-size: 20px;margin-left: 15px;margin-top: 20px;font-family: \'Bitter\';"><a href="#" style="color: rgb(0, 0, 238);">'. $row["username"] .'</a></h7>
            </div>
            <hr>
            <div class="text-muted h7 mb-2" style="font-family: \'Dosis\', sans-serif;"> <i class="fa fa-clock-o"></i>'. $row["date_time"] .'</div><br>
<div class="text2" style="font-family: \'Dosis\', sans-serif;">'. $row["source"] .'</div><br>
        <hr>
            <div class="card-footer"  style="font-family: \'Bitter\';">
                <a href="#" onclick="document.getElementById(\'id01'. $row["idpost"] .'\').style.display=\'block\'" class="card-link1"><i class="fa fa-comment"></i> Comment</a>
                <a href="#" class="card-link'. $row["idpost"] .'" style="margin-left: 130px;" onclick="return like'. $row["idpost"] .'();"><i class="fa fa-share"></i> Share</a>
                
          </div>
        </div>
</center>';
  echo '<div id="id01'. $row["idpost"] .'" class="modal">
  <span onclick="document.getElementById(\'id01'. $row["idpost"] .'\').style.display=\'none\'" class="close" title="Close Modal">&times;</span>
  <div class="modal-content" >';
?>   


<?php
  echo'<script type="text/javascript">
function post'. $row["idpost"] .'()
{
  var comment = document.getElementById("comment'. $row["idpost"] .'").value;
  var name = \''. $row["idpost"] .'\';
  if(comment && name)
  {
    $.ajax
    ({
      type:\'post\',
      url: \'post_comments.php\',
      data: 
      {
         user_comm:comment,
       user_name:name
      },
      success: function (response) 
      {
          alert("that comment is added");
      document.getElementById("all_comments").innerHTML=response+document.getElementById("all_comments").innerHTML;
      document.getElementById("comment'. $row["idpost"] .'").value="";
        document.getElementById("username").value="";
  
      }
    });
  }
  
  return false;
}
</script>';

?>
 <?php echo'  <form method=\'post\' action="" onsubmit="return post'. $row["idpost"] .'();" id="container">
    
    <textarea id="comment'. $row["idpost"] .'" style="width: 99%;"  placeholder="Write Your Comment Here....."></textarea>  
    <input type="submit" value="Post Comment" style="width: 99%;height: 30px;margin-left: 3px;background-color: #6495ed;;border: none;color: white;text-decoration: none;" id="submit">
  </form>';?>
  <?php
}
echo'<div id="all_comments">';
    $host1="localhost";
    $username1="root";
    $password1="";
    $databasename1="semicolon";

    $connect1=mysqli_connect($host1,$username1,$password1,$databasename1);
    $comm1 = mysqli_query($connect1,"SELECT * FROM `comment` WHERE idpost='$idpost'; ");
     foreach ($comm1 as $roww1) 
    {
      echo '<p>'. $roww1['comment'].' </p><hr>';
      }
  echo' </div>
</div></div>
';
    echo '<script type="text/javascript" src="../js/javascript.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
        <script>
// Get the modal
var modal = document.getElementById(\'id01'. $row["idpost"] .'\');
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>';
 }
      }
      ?>


</body>
</html>
