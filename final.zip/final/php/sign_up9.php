<?php
include "../database.php";
	$firstname=$_POST['firstname9'];
    $lastname=$_POST['lastname9'];  
    $usename_valus=$_POST['username9'];
    $email=$_POST['email9'];
    $password=$_POST['password9'];  
    $getUse = $connect->prepare("SELECT * FROM user WHERE email='".$email."'");
    $getUse->execute();
    $use = $getUse->fetchAll();
    foreach ($use as $us) 
    {
      if ($email==$us['email']) 
      {
        echo "<script type='text/javascript'>";
        echo "alert(\"email is used\")";
        echo "</script>";
        exit;
      }
    }
    $getUsers = $connect->prepare("SELECT * FROM user WHERE username='".$usename_valus."'");
    $getUsers->execute();
    $users = $getUsers->fetchAll();
    foreach ($users as $user) 
    {
      if ($usename_valus==$user['username']) 
      {
        echo "<script type='text/javascript'>";
        echo "alert(\"username is used\")";
        echo "</script>";
        exit;
      }
    }
    $stmt = $connect->query("INSERT INTO `user` (`firstname`, `lastname`, `username`, `email`, `password`) VALUES ('$firstname', '$lastname','$usename_valus', '$email', '$password');");
    setcookie("semicolon",$usename_valus);
    header("Location:../pages/settings.php");
    exit;

?>