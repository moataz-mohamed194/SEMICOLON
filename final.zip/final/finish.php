<?php
	error_reporting(0);
   	include 'php/create/database.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
	<meta name="description" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="css/sign.css">
	<link rel="shortcut icon"  href="photo/SEMICOLON.jpg">
	<title>SEMICOLON</title>
	<style type="text/css">
.modal1 {
    display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}
.modal12 {
    display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.close:hover,
.close:focus {
  color: #f44336;
  cursor: pointer;
}
@media only screen and (max-width: 1060px){
	#list{display: none;}
	#sub111{display:block;width: 20%;margin: 10% 40%; }
	
}
	
@media only screen and (max-width: 888px){
	#text1{display: none;}
	#sub222{display:block; width: 20%;margin: 10% 40%;}
	
}	
@media only screen and (max-width: 350px){
	
	#sub222{width: 40%;margin: 10% 30%; }
	#sub111{width: 40%;margin: 10% 30%; }

}
	</style>
</head>
<body id="body">
<div id="navbar" class="navbar" >
	
	<b id="d"><span class="semi" id="semi"> welcome geek</span></b>
	<form class="text1" method="post" id="text1">
		<input type="text" name="username" placeholder="username"  class="nav1" id="user12"/>
		<input type="password"placeholder="password" name="password"  class="nav1" id="user123"/>
		<i id="open" class="fa fa-eye" aria-hidden="true" onClick="viewPassword()"></i>
		<input type="submit" value="sign in" name="submittt" class="button" id="sub12">
	</form>
</div>
<?php

  if(isset($_POST["submittt"]))
  {
  	 $username1=$_POST['username'];
    $password=$_POST['password'];
    $getUsers = $connect->prepare("SELECT * FROM user WHERE username='".$username1."'");
    $getUsers->execute();
    $users = $getUsers->fetchAll();
    foreach ($users as $user) 
    {
      if($password==$user['password'])
      {
        setcookie("semicolon",$username1 );
        $link = "<script>window.open('../final/pages/home.php','_self')</script>";
		echo $link;
      //  header("Location:../final/pages/home.php");
        exit;
      }
      if ($password!=$user['password']) 
      {
        //  header("Location:try - Copy.php");
        //echo "not the same";
        echo "<script type='text/javascript'>";
        echo "alert(\"wrong passsword\")";
        echo "</script>";
        exit;
      }
    }
  }

  ?>

<br>
<button   class="submit111"  name="submit" value="" id="sub111"style="" onclick="document.getElementById('id011').style.display='block'"> sign up</button>
<button   class="submit222"  name="submit" value="" id="sub222"style=""  onclick="document.getElementById('id01').style.display='block'"> sign in</button>
<div id="list">
	<ul>
		<li class="top"><strong> sign up</strong></li> 
		<form class="sign" method="post" >
			<li class="head1">
				<input type="text" name="firstname" id="first" placeholder="first name" class="input"/>
			</li>
			<li class="head1">
				<input type="text" name="lastname" id="second" placeholder="last name" class="input"/>
			</li>
			<li class="head1">
				<input type="username" name="username" id="email" placeholder="username" class="input"/>
			</li>
			<li class="head1">
				<input type="email" name="email" id="email" placeholder="email" class="input"/>
			</li>
			<li class="head1">
				<input type="password" name="password" placeholder="password" name="password"   class="nav" id="passwordd" />
  				<i id="openeyes" class="fa fa-eye" aria-hidden="true" onClick="viewPassword1()"></i>
			</li>
			<input type="submit"  class="submit"  name="submit" value="sign up" id="sub">
		</form>
	</ul>
</div>
<?php
// to create the table
include 'php/create/create_finish_and_connect.php';
  
//to sent data to database if u new user
if(isset($_POST['submit'])&&!empty($_POST['firstname'])&&!empty($_POST['lastname'])&&!empty($_POST['username'])&&!empty($_POST['email'])&&!empty($_POST['password']))
  {
  	include "create/database.php";


	$firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];  
    $usename_valus=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];  
    $getUse = $connect->prepare("SELECT * FROM user WHERE email='".$email."'");
    $getUse->execute();
    $use = $getUse->fetchAll();
    foreach ($use as $us) 
    {
      if ($email==$us['email']) 
      {
        echo "<script type='text/javascript'>";
        echo "alert(\"email is used\")";
        echo "</script>";
        exit;
      }
    }
    $getUsers = $connect->prepare("SELECT * FROM user WHERE username='".$usename_valus."'");
    $getUsers->execute();
    $users = $getUsers->fetchAll();
    foreach ($users as $user) 
    {
      if ($usename_valus==$user['username']) 
      {
        echo "<script type='text/javascript'>";
        echo "alert(\"username is used\")";
        echo "</script>";
        exit;
      }
    }
    $stmt = $connect->query("INSERT INTO `user` (`firstname`, `lastname`, `username`, `email`, `password`) VALUES ('$firstname', '$lastname','$usename_valus', '$email', '$password');");
    setcookie("semicolon",$usename_valus);
        $link = "<script>window.open('pages/settings.php','_self')</script>";
		echo $link;
    
    exit;
    
  }



		


     
 ?>

<div id="id01" class="modal1">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal" style="font-family: Arial, Helvetica, sans-serif;">&times;</span>
  <center><form method="post" class="modal-content">
		<p class="label-input100" style="margin-top: 5%;font-size: 25px;font-family: Arial, Helvetica, sans-serif;margin-bottom: 10px;">Username</p>
		<input type="text" name="username999" placeholder="username"   style="border: none;outline: none;background: none;font-size: 18px;width: 50%;border-bottom: 2px solid cornflowerblue;" /><br>
		<p class="label-input100" style="margin-top: 5%;font-size: 25px;font-family: Arial, Helvetica, sans-serif;margin-bottom: 10px;">Password</p>
		<input type="password"placeholder="password" name="password999"  style="border: none;outline: none;background: none;font-size: 18px;width: 50%;border-bottom: 2px solid cornflowerblue;" />
		<i id="open" class="fa fa-eye" aria-hidden="true" onClick="viewPassword()"></i>
		<br><input type="submit" value="sign in" name="submittt999" style="margin-top: 5%;margin-bottom: 5%;width: 50%;background: #6495ed;border: none;color: white;padding: 5px;font-size: 18px;cursor: pointer;margin: 12px 0px 12px 10px;">
	</form></center>
</div>
<?php
include 'php/create/create_finish_and_connect.php';

 	include "php/create/database.php";

  if(isset($_POST["submittt999"]))
  {
  	 $username1=$_POST['username'];
    $password=$_POST['password'];
    $getUsers = $connect->prepare("SELECT * FROM user WHERE username='".$username1."'");
    $getUsers->execute();
    $users = $getUsers->fetchAll();
    foreach ($users as $user) 
    {
      if($password==$user['password'])
      {
        setcookie("semicolon",$username1 );
        $link = "<script>window.open('../final/pages/home.php','_self')</script>";
		echo $link;
      //  header("Location:../final/pages/home.php");
        exit;
      }
      if ($password!=$user['password']) 
      {
        //  header("Location:try - Copy.php");
        //echo "not the same";
        echo "<script type='text/javascript'>";
        echo "alert(\"wrong passsword\")";
        echo "</script>";
        exit;
      }
    }
  }

  ?>
<div id="id011" class="modal12">
  <span onclick="document.getElementById('id011').style.display='none'" class="close" title="Close Modal" style="font-family: Arial, Helvetica, sans-serif;">&times;</span>
  <center><form  method="post" class="modal-content">
			<li class="head1" style="margin:0px;width: 50% ">
				<p class="label-input100" style="/* margin-top: 5%; */font-size: 25px;font-family: Arial, Helvetica, sans-serif;/* margin-bottom: 10px; */margin-bottom: 0px;">First Name</p>
				<input type="text" name="firstname9" id="first" placeholder="first name" class="input" style="color: black;" />
			</li>
			<li class="head1" style="margin:0px;width: 50% ">
				<p class="label-input100" style="/* margin-top: 5%; */font-size: 25px;font-family: Arial, Helvetica, sans-serif;/* margin-bottom: 10px; */margin-bottom: 0px;">Last Name</p>
				<input type="text"  id="second" name="lastname9" placeholder="last name" class="input" style="color: black;"/>
			</li>
			<li class="head1" style="margin:0px;width: 50% ">
				<p class="label-input100" style="/* margin-top: 5%; */font-size: 25px;font-family: Arial, Helvetica, sans-serif;/* margin-bottom: 10px; */margin-bottom: 0px;">Username</p>
				<input type="username"  id="email" placeholder="username" name="username9" class="input" style="color: black;"/>
			</li>
			<li class="head1" style="margin:0px;width: 50% ">
				<p class="label-input100" style="/* margin-top: 5%; */font-size: 25px;font-family: Arial, Helvetica, sans-serif;/* margin-bottom: 10px; */margin-bottom: 0px;">Email</p>
				<input type="email" id="email" placeholder="email" name="email9" class="input" style="color: black;"/>
			</li>
			<li class="head1" style="margin:0px;width: 50% ">
				<p class="label-input100" style="font-size: 25px;font-family: Arial, Helvetica, sans-serif;/* margin-bottom: 10px; */margin-bottom: 0px;">Password</p>
				<input type="password"  placeholder="password" name="password9"   class="nav" id="passwordd"  style="color: black;"/>
  				<i id="openeyes" class="fa fa-eye" aria-hidden="true" onClick="viewPassword1()"></i>
			</li>
			<input type="submit" name="submit9" style="margin-top: 5%;margin-bottom: 5%;width: 50%;background: #6495ed;border: none;color: white;padding: 5px;font-size: 18px;cursor: pointer;" value="sign up" id="sub">
		</form></center>
</div>
<?php
// to create the table
include 'php/create/create_finish_and_connect.php';
  
//to sent data to database if u new user
if(isset($_POST['submit9'])&&!empty($_POST['firstname9'])&&!empty($_POST['lastname9'])&&!empty($_POST['username9'])&&!empty($_POST['email9'])&&!empty($_POST['password9']))
  {
  	include "create/database.php";


	$firstname=$_POST['firstname9'];
    $lastname=$_POST['lastname9'];  
    $usename_valus=$_POST['username9'];
    $email=$_POST['email9'];
    $password=$_POST['password9'];  
    $getUse = $connect->prepare("SELECT * FROM user WHERE email='".$email."'");
    $getUse->execute();
    $use = $getUse->fetchAll();
    foreach ($use as $us) 
    {
      if ($email==$us['email']) 
      {
        echo "<script type='text/javascript'>";
        echo "alert(\"email is used\")";
        echo "</script>";
        exit;
      }
    }
    $getUsers = $connect->prepare("SELECT * FROM user WHERE username='".$usename_valus."'");
    $getUsers->execute();
    $users = $getUsers->fetchAll();
    foreach ($users as $user) 
    {
      if ($usename_valus==$user['username']) 
      {
        echo "<script type='text/javascript'>";
        echo "alert(\"username is used\")";
        echo "</script>";
        exit;
      }
    }
    $stmt = $connect->query("INSERT INTO `user` (`firstname`, `lastname`, `username`, `email`, `password`) VALUES ('$firstname', '$lastname','$usename_valus', '$email', '$password');");
    setcookie("semicolon",$usename_valus);
        $link = "<script>window.open('pages/settings.php','_self')</script>";
		echo $link;
    
    exit;
    
  }



		


     
 ?>

<script type="text/javascript" src="js/sign.js">
	  
</script>

</body>
</html>
<?php/*
// to create the table
include 'php/create/create_finish_and_connect.php';
  
//to sent data to database if u new user
if(isset($_POST['submit'])&&!empty($_POST['firstname'])&&!empty($_POST['lastname'])&&!empty($_POST['username'])&&!empty($_POST['email'])&&!empty($_POST['password']))
  {
  	include 'php/sign_up.php';
    
  }
*/


		


     
 ?>

