<?php
 $source1=$_POST['source'];

echo'
<script type="text/javascript">
  alert('.$source1.');
 alert('.$_POST['source'].');
</script>
';
?>