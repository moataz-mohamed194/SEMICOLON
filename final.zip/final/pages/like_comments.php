<?php

  $host="localhost";
  $username="root";
  $password="";
  $databasename="semicolon";
  $connect=mysqli_connect($host,$username,$password,$databasename);
  /*if(isset($_POST['idpost']) && isset($_POST['iduser']))
  {
    $idpost=$_POST['idpost'];  
    $iduser=$_POST['iduser'];
    $insert=mysqli_query($connect,"insert into likes (idpost,iduser) values('$idpost','$iduser')");
    $name='semicolon' ;
	  $comment='comment';
    exit;
  }*/
      $date=date("y-m-d h:i:s",time()+0*60*60);
  $us=$_COOKIE['semicolon'];
  $source1=$_POST['source'];
 include "create/database.php";
 $insert=mysqli_query($connect,"insert into post (username,date_time,source) values('$us','$date', '$source1')");
     echo'<script type="text/javascript">
      alert( 33333333333);
      </script>';
      exit;
 
?>