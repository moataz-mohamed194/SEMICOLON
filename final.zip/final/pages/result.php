<?php
/**
 * WHERE search LIKE '%{$keywords}%' OR name LIKE '%{$keywords}%'
 */
 $username = 'root';
  $password = '';
  $dsn = 'mysql:host=localhost;dbname=semicolon';
 // $conn = new PDO($dsn, $username, $password);
  $conn=new mysqli( "localhost","root","","semicolon");
  echo"llllllll";
  if(isset($_POST['keywords']))
  {
    $keywords=$conn->real_escape_string($_POST['keywords']);
    $query=$conn->query("
      SELECT * FROM `user` WHERE `semicolon` LIKE '%{$keywords}%' OR email LIKE '%{$keywords}%'
      ");
    $conn= mysqli_connect( "localhost","root","","semicolon");
$queryy=mysqli_query($conn,"SELECT * FROM user WHERE email LIKE '%$keywords%'");
    //mysqli_num_rows()
      $a=mysqli_num_rows($queryy);
         echo" found".$a."<br>";  
         
         if ($a>0)
         {
          while ($row=mysqli_fetch_assoc($queryy)) 
          {
            echo $row['email']."<br>";
            echo $row['username']."<br>";
          }
          }else{
            echo "nothing";
            # code...
          }
         }
        ?>