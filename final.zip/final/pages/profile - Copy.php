<?php 
error_reporting(0);
if(!isset($_COOKIE['semicolon'])) 
    {
        header("Location:../finish.php");
    }
// to connect the database
    include '../php/create/database.php';
    //to sent the post to database
    if(isset($_POST['sharepost']))
    {
    include '../php/share_efrom_my_profile.php';
    }

    $day=date("Y-m-d");
    $query ="SELECT * FROM post";
    $data=$connect->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="description" content="">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Bitter&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Dosis&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/profile.css">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="../js/javascript.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <script type="text/javascript" src="../js/javascript.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="../js/profile.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="shortcut icon"  href="../photo/SEMICOLON.jpg">
    <title>SEMICOLON</title>
    <style type="text/css">
        .modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}
#col-sm-9911{display: none;}
/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}
 header{
      font-family: 'Bitter', serif;
      font-size: 18px;

     }
 .update{
            }
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  cursor: pointer;
  font-weight: bold;
  color: #f1f1f1;
}
#col-sm-9999{display: none;}
 #li12366{margin-left: 60%;}
 #col-sm-99{display: block;}
}
#post{}
#col-sm-9{display: block;}
@media only screen and (max-width: 1346px){
  #li12366{margin-left: 55%;}
  
}
@media only screen and (max-width: 1050px){
  #li12366{margin-left: 50%;}
  
}
@media only screen and (max-width: 1312px){
  #li12366{margin-left: 45%;}
  #col-sm-9999{display: block;}
  #col-sm-9{display: none;}
  #col-sm-99{display: none;}
  #post{float: right;margin-right: 20px;}
  #firstt{float: right;margin-right: 3%;}
  #col-sm-9911{display: block;}
  #message{margin-left: 5px;}
	#update{float: right;margin-right: 4%;}
}
@media only screen and (max-width: 810px){
  #li12366{margin-left: 30%;}
  
}

@media only screen and (max-width: 681px){
  #li12366{margin-left: 10%;}
  #li1235555{display: none;}
  
} 

#col-sm-923242{display: none;}
@media only screen and (max-width: 954px){
  #li12366{margin-left: 10%;}
  #col-sm-9999{display: none;}
  #col-sm-923242{display: block;}
  #update{margin: 0px 23%;}
  #post{margin: 15px 20%;}
  
} 

    </style>

</head>
<body>
    
<header class="header123" style="font-family: 'Bitter', serif;font-size:  18.8px;position: fixed;top: 0;">
    <div class="overlay"></div>
        <div class="container" style="margin-top: 10px;margin-bottom: 10px;">
            <nav id="nav123" calss="nav123">
                <ul class="ul123" id="ul123" style="margin-top: 0px;margin-bottom: 0px;">
                  <li class="li1234" id="li123" style="margin-left: 3%;margin-top: 2px;"><img id="img" src="../photo/g.jpg"></li>
                  <li class="li1234" id="li1235555"style=" margin-left: 3%">
                    <div class="wrapper">
                        <form action="search.php"  method="POST">
                <div class="searchbox">
                  <input type="search" class="input" name="keywords">
                     <button class="searchbtn" type="submit" style="left: 0px;margin-top: 0px;"><i class="fas fa-search"></i></button>
             
              </div></form>
             </div>
          </li>
                  <li class="li12345" id="li12366" style="  color: #FFD500;"><a class="a12345" style=" color:white " href="home.php">Home</a></li>
                  <li class="li123456" id="li123" style=" margin-left: 3%;  color: white;"><a class="a123456" style=" color:#FFD500"  href="profile.php"><?php echo $_COOKIE['semicolon'] ;?></a></li>
                  <li class="li1234567" id="li123" style=" margin-left: 3%;  color: white;"><a class="a1234567" style=" color:white "href="../finish.php">sign out</a></li>
                </ul>
            </nav>
        </div>
</header>
            
    <?php
                    $getUse = $connect->prepare("SELECT * FROM user WHERE username='".$_COOKIE['semicolon']."'");
      $getUse->execute();
      $use = $getUse->fetchAll();
      foreach ($use as $us) 
      {
        $age=$day-$us['birthday'];
                ?>
    <div class="row" style="margin-top: 50px;">
        <div class="col-xs-12 col-sm-3 center">
            <span class="profile-picture">
                <img class="editable img-responsive" alt=" Avatar" id="avatar2" height="200" width="180" src="../photo/<?php echo $us['img']; ?>">
            </span>
            <div class="space space-4"></div>
            <a href="settings.php" class="btn btn-sm btn-block btn-primary"style="color: rgb(0, 0, 238);">
                <i class="material-icons" style="font-size:16px">settings</i>
                <span class="bigger-110">Update Profile</span>
            </a>
        </div><!-- /.col -->
            <div id="col-sm-9" class="col-xs-12 col-sm-9" style="margin-top: 0px;">
                
            <h4 class="blue" style="font-family: 'Bitter'">
                <span class="middle"><?php echo $_COOKIE['semicolon']; ?></span>                            
            </h4>
            <div class="profile-user-info">
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Location </div>
                        <div class="profile-info-value">
                            <i class="fa fa-map-marker light-orange bigger-110"></i>
                            <span><?php echo $us['location']; ?></span>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Age </div>
                        <div class="profile-info-value">
                            <span><?php echo $age; ?></span>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Birthday </div>
                        <div class="profile-info-value">
                            <span><?php echo $us['birthday']; ?></span>
                        </div>
                    </div>
                </div>
                <div class="hr hr-8 dotted"></div>
                <div class="profile-user-info">
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Website </div>
                        <div class="profile-info-value">
                            <a href="#" target="_blank">www.alexdoe.com</a>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name">
                            <i class="middle ace-icon fa fa-facebook-square bigger-150 blue"></i>
                        </div>
                        <div class="profile-info-value">
                            <a href="<?php echo $us['facebook']; ?>">Find me on Facebook</a>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name">
                                <i class="middle ace-icon fa fa-twitter-square bigger-150 light-blue"></i>
                        </div>
                        <div class="profile-info-value">
                            <a href="<?php echo $us['twitter']; ?>">Follow me on Twitter</a>
                        </div>
                    </div>
                </div>
            </div><!-- /.col -->
            <div id="col-sm-99" class="col-xs-12 col-sm-6" style="margin-top: 0px;">
                <div id="widget-box" class="widget-box transparent">
                    <div class="widget-header widget-header-small">
                        <h4 class="widget-title smaller" style="font-family: 'Bitter', serif;">
                                <i class="ace-icon fa fa-check-square-o bigger-110"></i>
                                Little About Me
                        </h4>
                    </div>
                    <div class="widget-body">
                        <div class="widget-main">
                            <p>
                                <?php echo $us['aboutme']; }?>
                            
                            </p>
                        </div>
                    </div>
                </div>
            </div>
             <div class="mobile" id="mobile">
         <div id="col-sm-9999" class="col-xs-12 col-sm-9" style="margin-top: 0px;">
                
            <h4 class="blue" style="font-family: 'Bitter'">
                <span class="middle"><?php echo $_COOKIE['semicolon']; ?></span>                            
            </h4>
            <div class="profile-user-info">
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Location </div>
                        <div class="profile-info-value">
                            <i class="fa fa-map-marker light-orange bigger-110"></i>
                            <span><?php echo $us['location']; ?></span>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Age </div>
                        <div class="profile-info-value">
                            <span><?php echo $age; ?></span>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Birthday </div>
                        <div class="profile-info-value">
                            <span><?php echo $us['birthday']; ?></span>
                        </div>
                    </div>
                </div>
                <div class="hr hr-8 dotted"></div>
                <div class="profile-user-info">
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Website </div>
                        <div class="profile-info-value">
                            <a href="#" target="_blank">www.alexdoe.com</a>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name">
                            <i class="middle ace-icon fa fa-facebook-square bigger-150 blue"></i>
                        </div>
                        <div class="profile-info-value">
                            <a href="<?php echo $us['facebook']; ?>">Find me on Facebook</a>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name">
                                <i class="middle ace-icon fa fa-twitter-square bigger-150 light-blue"></i>
                        </div>
                        <div class="profile-info-value">
                            <a href="<?php echo $us['twitter']; ?>">Follow me on Twitter</a>
                        </div>
                    </div>
                </div>
            </div><!-- /.col -->
           
            </div>
       <div id="firstt" >

            <div id="col-sm-923242" class="col-xs-12 col-sm-9" style="margin-top: 0px;position: static;">
                
            <h4 class="blue" style="font-family: 'Bitter'">
                <span class="middle"><?php echo $_COOKIE['semicolon']; ?></span>                            
            </h4>
            <div class="profile-user-info">
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Location </div>
                        <div class="profile-info-value">
                            <i class="fa fa-map-marker light-orange bigger-110"></i>
                            <span><?php echo $us['location']; ?></span>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Age </div>
                        <div class="profile-info-value">
                            <span><?php echo $age; ?></span>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Birthday </div>
                        <div class="profile-info-value">
                            <span><?php echo $us['birthday']; ?></span>
                        </div>
                    </div>
                </div>
                <div class="hr hr-8 dotted"></div>
                <div class="profile-user-info">
                    <div class="profile-info-row">
                        <div class="profile-info-name"> Website </div>
                        <div class="profile-info-value">
                            <a href="#" target="_blank">www.alexdoe.com</a>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name">
                            <i class="middle ace-icon fa fa-facebook-square bigger-150 blue"></i>
                        </div>
                        <div class="profile-info-value">
                            <a href="<?php echo $us['facebook']; ?>">Find me on Facebook</a>
                        </div>
                    </div>
                    <div class="profile-info-row">
                        <div class="profile-info-name">
                                <i class="middle ace-icon fa fa-twitter-square bigger-150 light-blue"></i>
                        </div>
                        <div class="profile-info-value">
                            <a href="<?php echo $us['twitter']; ?>">Follow me on Twitter</a>
                        </div>
                    </div>
                </div>
            </div><!-- /.col -->
            <center>
            <div class="update" id="update" style="margin-left: 30px;margin-top: 0px;">
        <ol id="text">
            <li><a onclick="publication()" style="color:  #3366cc;font-family: 'Bitter', serif;"><b>Make a publication</b></a></li>
            
        </ol>
        <div class="posts">
            <form method="post">
            <div class="form-group" id="form-group">
                <textarea class="form-control" id="message" name="thatpost" cols="50" rows="5" placeholder="What are you thinking?"></textarea>
            </div>
            
        </div>
        <ol class="form">
            <li >
                    <input id="d" type="submit" onclick="share133()"  class="button2" value="Share" name="sharepost">
                </form>
            </li>
            <li class="dropdown"  style="margin-left: 200px;margin-right: 100px;">
                <a href="javascript:void(0)" class="dropbtn" ><div  class="fa fa-globe" id="faaaa"> </div>   </a>
                <div class="dropdown-content" >
                    <a href="#" class="fa fa-globe" onclick="fa_globe()">Public</a>
                    <a href="#" class="fa fa-users" onclick="fa_users()">Friends</a>
                    <a href="#" class="fa fa-user" onclick="fa_user()">Just me</a>
                </div>
            </li>
        </ol>
    </div>
    </center>
        
            <?php   include '../php/posts_from_my_profile.php'; ?>
</div>
        </div>
<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <div class="modal-content" >
      <p>that important queation </p><hr>
        <p>that important queation </p>
  </div>
</div>


        <script type="text/javascript" src="../js/javascript.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
        <script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

<script type="text/javascript">
  
$(document).ready(function(){
  $(".wrapper").mouseenter(function(){
    $(this).toggleClass("bg-green"); 
  $(".input").focus().toggleClass("active-width").val('');
  });
   $(".wrapper").mouseleave(function(){
  $(".input").focus().toggleClass("active-width").val('');
  });


  $(".li12345").mouseenter(function(){
    $(".a12345").css("color", "#FFD500");
  });
   $(".li12345").mouseleave(function(){
    $(".a12345").css("color", "white");
  });
  $(".li1234567").mouseenter(function(){
    $(".a1234567").css("color", "#FFD500");
  });
   $(".li1234567").mouseleave(function(){
    $(".a1234567").css("color", "white");
  });
  
});
</script>
</body>
</body>
</html>