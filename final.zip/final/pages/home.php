<?php
    if(!isset($_COOKIE['semicolon'])) 
    {
        header("Location:../finish.php");
    }
    // to connect to the dayabase
    include '../php/create/create_home.php';
    //to sent the data to database
   	function re(){
	 
	$cookie_name = 'semicolonn';
unset($_COOKIE[$cookie_name]);
// empty value and expiration one hour before
$res = setcookie($cookie_name, '', time() - 3600);
 }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Bitter&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Dosis&display=swap" rel="stylesheet">

    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
    <script type="text/javascript" src="../js/javascript.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <meta name="description" content="">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="shortcut icon"  href="../photo/SEMICOLON.jpg">
    <title>SEMICOLON</title>
    <script>
 $(document).ready(function(){
  $(".button2").click(function(){

 	var source =document.getElementById("message").value;
   var iduser =0;
    $.ajax({
      url: 'post.php',
      type: 'post',
      data: 
      {
        source: source,
        iduser: iduser
      },
      success: function(response)
      {
        alert("your post is shared");
        }
      });
  });
});</script>

    <style type="text/css">
    #li12366{margin-left: 60%;}
@media only screen and (max-width: 1346px){
  #li12366{margin-left: 55%;}
  
}
@media only screen and (max-width: 1050px){
  #li12366{margin-left: 50%;}
  
}

@media only screen and (max-width: 1151px){
  #li12366{margin-left: 45%;}
  #card, #left {
    display: inline-block;
    display: none;
}
#dropdown{

    margin-left: 70%;
}
#post{
width: 80%;  
}

.update {
    width: 80%;
}
#text2{
  margin-left: 0px;
}
#message{
  width: 90%;
    margin-top: 10px;
}
}
 
@media only screen and (max-width: 898px){
  #li12366{margin-left: 40%;}
  
}
@media only screen and (max-width: 810px){
  #li12366{margin-left: 30%;}
  
} 

@media only screen and (max-width: 681px){
  #li12366{margin-left: 10%;}
  #li1235555{display: none;}
  
} 
    </style>
  </head>
  <body style=""> 
   
<header class="header123" style="font-family: 'Bitter', serif;font-size:  18.8px;position: fixed;top: 0;">
    <div class="overlay"></div>
        <div class="container" id="container" style="margin-top: 10px;margin-bottom: 10px;">
            <nav id="nav123" calss="nav123">
                <ul class="ul123" id="ul123" style="margin-top: 0px;margin-bottom: 0px;">
                  <li class="li1234" id="li123" style="margin-left: 3%;margin-top: 2px;"><img id="img" src="../photo/g.jpg"></li>
                  <li class="li1234" id="li1235555"style=" margin-left: 3%">
                    <div class="wrapper">
                       <form action="search.php"  method="POST">
                <div class="searchbox">
                  <input type="search" class="input" name="keywords">
                     <button class="searchbtn" type="submit" style="left: 0px;"><i class="fas fa-search"></i></button>
             
              </div></form>
            </div>
          </li>
                  <li class="li12345" id="li12366" style="  color: #FFD500;"><a class="a12345" style=" color:#FFD500 " href="home.php">Home</a></li>
                  <li class="li123456" id="li123" style=" margin-left: 3%;  color: white;"><a class="a123456" style=" color:white"  href="profile.php"><?php echo $_COOKIE['semicolon'] ;?></a></li>
                  <li class="li1234567" id="li123" style=" margin-left: 3%;  color: white;" onClick="<?php re(); ?>"><a class="a1234567" style=" color:white "href="../finish.php">sign out</a></li>
                  <div class="mobile-container">

<!-- Top Navigation Menu -->

                </ul>
            </nav>
        </div>
</header>
                


    <div class="first" style="margin-top: 50px;">
      <center>
        <div class="update" id="update" >
          <ol id="text">
            <li>
              <a onclick="publication()" style="color:  #3366cc;font-family: 'Bitter', serif;">
                <b>Make a publication</b>
              </a>
            </li>
          </ol>
          <div class="posts">
            <form method="post">
              <div class="form-group" id="form-group">
                <textarea class="form-control" name="thatpost" id="message" cols="58" rows="5" placeholder="What are you thinking?"></textarea>
              </div>
          </div>
            <ol class="form">
              <li>
                <input id="d" type="submit" onclick="share133()"  class="button2" value="Share" name="sharepost">
            </form>
              </li>
              <li class="dropdown" id="dropdown"  >
                <a href="javascript:void(0)" class="dropbtn" >
                  <div  class="fa fa-globe" id="faaaa"> </div>   
                </a>
                <div class="dropdown-content" >
                  <a href="#" class="fa fa-globe" onclick="fa_globe()">Public</a>
                  <a href="#" class="fa fa-users" onclick="fa_users()">Friends</a>
                  <a href="#" class="fa fa-user" onclick="fa_user()">Just me</a>
                </div>
              </li>
          </ol>
        </div>
      </center>
    <div class="card" id="card" >
      <div class="card-body">
        <div style="padding-bottom: 0px; font-family: 'Bitter', serif;" class="h5" id="name">New in tracks</div>
      </div>
      <ul  class="list-group list-group-flush">
        <li class="list-group-item">
          <div class="h6 text-muted">web developer </div>
          <div class="h5">WebAssembly </div>
        </li>
        <li class="list-group-item">
          <div class="h6 text-muted">Android</div>
          <div class="h5">Flutter</div>
        </li>
        <li class="list-group-item">Vestibulum at eros</li>
      </ul>
    </div>
    <div class="left" style="height: 500px;" id="left">
      <p id="name" style=" font-family: 'Bitter', serif;">Ten Best Programming Languages </p>
      <div >
        <p  >1. Python</p>
      </div>
      <div >
        <p  >2. JavaScript</p>
      </div>
      <div >
        <p >3. Rust</p>
      </div>
      <div >
        <p >4. Go</p>
      </div>
      <div >
        <p >5. Swift</p>
      </div>
      <div >
        <p >6. Kotlin</p>
      </div>
      <div >
        <p>7. C++</p>
      </div>
      <div >
        <p>8. TypeScript</p>
      </div>
      <div >
        <p>9. Java</p>
      </div>
      <div >
        <p>10. F#</p>
      </div>
    </div>
    </div>
    <div id="firstt" >
    <?php   
	$query ="SELECT * FROM post ORDER BY idpost desc ";
    $data=$connect->query($query);
    foreach ($data as $row) 
    {
     	$g = $connect->prepare("SELECT * FROM user WHERE username='".$row['username']."'");
     	$g->execute();
     	$u = $g->fetchAll();
  		$idpost=$row["idpost"];
      	foreach ($u as $us1) 
      	{
echo'<script>
 $(document).ready(function(){
  $(".card-link'. $row["idpost"] .'").click(function(){';

  echo' var source ="'.$row["source"].'";
   var iduser =0;
    $.ajax({
      url: \'like_comments.php\',
      type: \'post\',
      data: 
      {
        source: source,
        iduser: iduser
      },
      success: function(response)
      {
        alert("that post is shared");';
       
echo'        }
      });
  });
});</script>
';

       echo' <center st>'.
'         <div class="post" id="post">
            <div class="posthead">
             <img id="pro1" src="../photo/'.$us1['img'].'">
            <h7 id="name1" style="font-size: 20px;font-size: 20px;margin-left: 15px;margin-top: 20px;font-family: \'Bitter\';color: rgb(0, 0, 238);"><a href="" style="
    color: rgb(0, 0, 238);";
">'. $row["username"] .'</a></h7>
            </div>
            <hr>
            <div class="text-muted h7 mb-2" style="font-family: \'Dosis\', sans-serif;"> <i class="fa fa-clock-o"></i>'. $row["date_time"] .'</div><br>
<div class="text2" id="text2" style="font-family: \'Dosis\', sans-serif;" >'. $row["source"] .'</div><br>
        <hr>
            <div class="card-footer" style="font-family: \'Bitter\';">
                <a href="#" onclick="document.getElementById(\'id01'. $row["idpost"] .'\').style.display=\'block\'" class="card-link1"style="color: rgb(0, 0, 238);"><i class="fa fa-comment" ></i> Comment</a>
                <a href="#" class="card-link'. $row["idpost"] .'" style="margin-left: 130px;color: rgb(0, 0, 238);" onclick="return like'. $row["idpost"] .'();"><i class="fa fa-share"></i> Share</a>
                
          </div>
        </div>
</center>';

   echo '<div id="id01'. $row["idpost"] .'" class="modal">
  <span onclick="document.getElementById(\'id01'. $row["idpost"] .'\').style.display=\'none\'" class="close" title="Close Modal">&times;</span>
  <div class="modal-content" >';
?>   


<?php
  echo'<script type="text/javascript">
function post'. $row["idpost"] .'()
{
  var comment = document.getElementById("comment'. $row["idpost"] .'").value;
  var name = \''. $row["idpost"] .'\';
  if(comment && name)
  {
    $.ajax
    ({
      type:\'post\',
      url: \'post_comments.php\',
      data: 
      {
         user_comm:comment,
       user_name:name
      },
      success: function (response) 
      {
          alert("that comment is added");
      document.getElementById("all_comments").innerHTML=response+document.getElementById("all_comments").innerHTML;
      document.getElementById("comment'. $row["idpost"] .'").value="";
        document.getElementById("username").value="";
  
      }
    });
  }
  
  return false;
}
</script>';

?>
 <?php echo'  <form method=\'post\' action="" onsubmit="return post'. $row["idpost"] .'();" id="container">
    
    <textarea id="comment'. $row["idpost"] .'" style="width: 99%;" placeholder="Write Your Comment Here....."></textarea><br>  
    <input type="submit" value="Post Comment" style="width: 99%;height: 30px;margin-left: 3px;background-color: #6495ed;border: none;color: white;text-decoration: none;" id="submit">
  </form>';?>
<?php echo'<div id="all_comments">';
    $host1="localhost";
    $username1="root";
    $password1="";
    $databasename1="semicolon";

    $connect1=mysqli_connect($host1,$username1,$password1,$databasename1);
    $comm1 = mysqli_query($connect1,"SELECT * FROM `comment` WHERE idpost='$idpost'; ");
     foreach ($comm1 as $roww1) 
    {
      echo '<p>'. $roww1['comment'].' </p><hr>';
      }
  echo' </div>
</div></div>
';
    echo '<script type="text/javascript" src="../js/javascript.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
        <script>
          var modal = document.getElementById(\'id01'. $row["idpost"] .'\');
          window.onclick = function(event) 
          {
            if (event.target == modal) 
            {
              modal.style.display = "none";
            }
          } 
        </script>';
 }
      }
      ?>
    </div>

<script type="text/javascript">
  
$(document).ready(function(){
  $(".wrapper").mouseenter(function(){
    $(this).toggleClass("bg-green"); 
  $(".input").focus().toggleClass("active-width").val('');
  });
   $(".wrapper").mouseleave(function(){
  $(".input").focus().toggleClass("active-width").val('');
  });


  $(".li123456").mouseenter(function(){
    $(".a123456").css("color", "#FFD500");
  });
   $(".li123456").mouseleave(function(){
    $(".a123456").css("color", "white");
  });
  $(".li1234567").mouseenter(function(){
    $(".a1234567").css("color", "#FFD500");
  });
   $(".li1234567").mouseleave(function(){
    $(".a1234567").css("color", "white");
  });
  
});
</script>
  </body>
</html>
<?php

?>