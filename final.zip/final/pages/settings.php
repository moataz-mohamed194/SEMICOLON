<?php
    //error_reporting(0);
    if(!isset($_COOKIE['semicolon'])) 
    {
        header("Location:../finish.php");
    }
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="description" content="">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/profile.css">
    <script type="text/javascript" src="../js/javascript.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Bitter&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Dosis&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Bitter&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Dosis&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <script type="text/javascript" src="../js/javascript.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="../js/profile.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="../js/profile.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="shortcut icon"  href="../photo/SEMICOLON.jpg">
    <title>SEMICOLON</title>
    <style type="text/css">
       header{
      

     }
      .upd{
        background-color: #008CBA;
        border: none;
        color: white;
        padding: 10px 25px;
        margin: 4px 2px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        cursor: pointer;
        border-radius: 10px;
        border-radius: 30px;
        }
 #li12366{margin-left: 60%;}

        @media only screen and (max-width: 1343px){
  #li12366{margin-left: 55%;}
  
}
@media only screen and (max-width: 1149px){
  #li12366{margin-left: 50%;}
  
}
@media only screen and (max-width: 1005px){
  #li12366{margin-left: 45%;}
  
}

@media only screen and (max-width: 896px){
  #li12366{margin-left: 40%;}
  
} 

#col-sm-923242{display: none;}
@media only screen and (max-width: 809px){
  #li12366{margin-left: 35%;}
  
} 
@media only screen and (max-width: 738px){
  #li12366{margin-left: 10%;}
  #li1232222{display: none;}
} 
@media only screen and (max-width: 521px){
  #li12366{margin-left: 5%;}
  
} 
    </style>

</head>
<body>
      
<header class="header123" style="font-family: 'Bitter', serif;font-size: 18px;">
    <div class="overlay"></div>
        <div class="container" style="margin-top: 10px;margin-bottom: 10px;">
            <nav id="nav123" calss="nav123">
                <ul class="ul123" id="ul123" style="margin-top: 0px;margin-bottom: 0px;">
                  <li class="li1234" id="li123" style="margin-left: 3%;margin-top: 2px;"><img id="img" src="../photo/g.jpg"></li>
                  <li class="li1234" id="li1232222"style=" margin-left: 3%">
                    <div class="wrapper">
                 <form action="search.php"  method="POST">
                <div class="searchbox">
                  <input type="search" class="input" name="keywords">
                     <button class="searchbtn" type="submit" style="left: 0px;margin-top: 0px;"><i class="fas fa-search"></i></button>
             
              </div></form>
            </div>
          </li>
                  <li class="li12345" id="li12366" style="  color: #FFD500;font-family: 'Bitter', serif;font-size: 18.8px;"><a class="a12345" style=" color:white " href="home.php">Home</a></li>
                  <li class="li123456" id="li123" style="font-family: 'Bitter', serif;font-size: 18.8px; margin-left: 3%;  color: white;"><a class="a123456" style=" color:white"  href="profile.php"><?php echo $_COOKIE['semicolon'] ;?></a></li>
                  <li class="li1234567" id="li123" style=" margin-left: 3%;  color: white;font-family: 'Bitter', serif;font-size: 18.8px;"><a class="a1234567" style=" color:white "href="../finish.php">sign out</a></li>
                </ul>
            </nav>
        </div>
</header>
  <div class="col-xs-12 col-sm-3 center">
    <span class="profile-picture">
      <img class="editable img-responsive" alt=" Avatar" id="avatar2" src="http://bootdey.com/img/Content/avatar/avatar6.png">
    </span>
    <form enctype="multipart/form-data"  method="post">
      <a href="#" id="col-sm-155"  class="btn btn-sm btn-block btn-primary">  
       <i class="material-icons" style="font-size:16px">add_to_photos</i>
       <input type="file" name="Update_your_image">
         <span class="bigger-110">Update your image </span>
      </a>
      <h4 class="blue">
        <span class="middle"><?php echo"username: ". $_COOKIE['semicolon'] ;?></span>              
      </h4>
      <span>
        <div class="profile-info-name" style="width: 50px;"> Location </div>
        <input type="text" width="20" height="20" name="Location"style="width: 170px;">              
      </span><br>
      <span>
        <div class="profile-info-name" style="width: 50px;"> Birthday </div>
        <input type="date" style="width: 170px;" name="Birthday">             
      </span><br>
      <span>
        <div class="profile-info-name" style="width: 50px;padding-right: 20px;"> Website </div>
        <a href="#" target="_blank" style="padding-right: 40px;">www.semicolon.com</a>              
      </span><br>
      <span>
        <i class="middle ace-icon fa fa-facebook-square bigger-150 blue" style="/*! padding-left: -10; */padding-right: 25px;"></i>
        <input type="text" style="width: 170px;margin-left: 1px;margin-right: -28px;" name="facebook">              
      </span><br><br>
      <span>
        <i class="middle ace-icon fa fa-twitter-square bigger-150 light-blue" style="/*! padding-left: -10; */padding-right: 25px;"></i>
        <input type="text" style="width: 170px;margin-left: 1px;margin-right: -28px;"  name="twitter">        
      </span>
      <h4 class="widget-title smaller">
        <i class="ace-icon fa fa-check-square-o bigger-110"></i>
                Little About Me
      </h4>
      <div class="widget-main" >
        <textarea style="width: 350px;height: 150px" name="aboutme"></textarea>        
      </div>
      <input type="submit" name="Updateyourdata" class="upd" value="Update your data">
    </form>
  </div>

<script type="text/javascript">
  
$(document).ready(function(){
  $(".wrapper").mouseenter(function(){
    $(this).toggleClass("bg-green"); 
  $(".input").focus().toggleClass("active-width").val('');
  });
   $(".wrapper").mouseleave(function(){
  $(".input").focus().toggleClass("active-width").val('');
  });


  $(".li12345").mouseenter(function(){
    $(".a12345").css("color", "#FFD500");
  });
   $(".li12345").mouseleave(function(){
    $(".a12345").css("color", "white");
  });
   $(".li123456").mouseenter(function(){
    $(".a123456").css("color", "#FFD500");
  });
   $(".li123456").mouseleave(function(){
    $(".a123456").css("color", "white");
  });
  $(".li1234567").mouseenter(function(){
    $(".a1234567").css("color", "#FFD500");
  });
   $(".li1234567").mouseleave(function(){
    $(".a1234567").css("color", "white");
  });
  
});
</script>
</body>
</html>
    <?php

    
    include '../php/create/database.php';
    if(isset($_POST["Updateyourdata"]))
    {
      include '../php/update_your_data.php';

    }

   
?>
    
