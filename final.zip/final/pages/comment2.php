<?php
  $host="localhost";
    $username="root";
    $password="";
    $databasename="semicolon";

    $connect=mysqli_connect($host,$username,$password,$databasename);

if(isset($_POST['user_comm']) && isset($_POST['user_name']))
{
/*   $idpost=$row["idpost"]; 
  $comment=$_POST['user_comm'];
  $name=$_POST['user_name'];*/
   $idpost=2; 
  $comment='user_comm';
  $name='user_name';
 
  $insert=mysqli_query($connect,"insert into comment (idpost,name,comment) values('$idpost','$name','$comment')");
  

	  $name='semicolon' ;
	  $comment='comment';
  ?>
<div class="comment_div"> 
 <p class="name"><strong>Posted By:</strong> <?php echo $name;?> </p>
 <p class="comments"><?php echo $comment;?></p>	
</div>
  <?php
 
exit;
}

?>