
<?php
  $host="localhost";
    $username="root";
    $password="";
    $databasename="semicolon";


    $connect=mysqli_connect($host,$username,$password,$databasename);
if(isset($_POST['user_comm']) && isset($_POST['user_name']))
{
  $idpost=$_POST['user_name'];  
  $comment=$_POST['user_comm'];
  $name=$_COOKIE['semicolon'] ;
  $insert=mysqli_query($connect,"insert into comment (idpost,name,comment) values('$idpost','$name','$comment')");
  

	  $name='semicolon' ;
	  $comment='comment';
  ?>

  <?php
 
exit;
}

?>